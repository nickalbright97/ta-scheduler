<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

  <?php include("calendar_script.php");?>
</head>
<body>
<div id='calendar'></div>
</div>
</body>
</html>
