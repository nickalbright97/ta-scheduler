# ta-scheduler
Project by Nick Albright, Connor Wallace, William Krzyzkowski, and Wesley Llamas.
We are creating a website to supplement the JMU CS TA hours. 


To Run : Place all code in a dirrectory.
Create the database
Connect the database to the db file if name / port changes
Run the DDL in the Database
Modify and Run the SEED in the database

Set the Environment variables in the server below:
SetEnv CANVAS_DEV_CLIENTID "190000000000515"
SetEnv CANVAS_DEV_SECRET "pj952yvk0Xn5QOSBZaNVWD4HijOdSc8DbNUNOHppjhYA9NuSYoVCLa5Z6GvK6fU6"
SetEnv CANVAS_URL https://canvas.jmu.edu

Go to host/home.php